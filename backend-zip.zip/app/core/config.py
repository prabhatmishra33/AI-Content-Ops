from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator


class Settings(BaseSettings):
    app_name: str = "AI Content Ops Backend"
    app_env: str = "dev"
    debug: bool = True
    database_url: str = "sqlite:///./backend.db"
    redis_url: str = "redis://localhost:6379/0"
    default_base_reward_points: int = 100

    # Threshold policy
    threshold_p0: float = 0.95
    threshold_p1: float = 0.90
    threshold_p2: float = 0.80

    # Distribution defaults
    youtube_publish_default_visibility: str = "unlisted"
    secondary_channel_name: str = "cms_webhook"
    hold_auto_create_gate1: bool = False

    # Celery queue names
    queue_ai_processing: str = "q.ai_processing"
    queue_review_p0: str = "q.review_p0"
    queue_review_p1: str = "q.review_p1"
    queue_review_p2: str = "q.review_p2"
    queue_review: str = "q.review"
    queue_hold: str = "q.hold"
    queue_report: str = "q.report"
    queue_reward: str = "q.reward"
    queue_distribution_youtube: str = "q.distribution_youtube"
    queue_distribution_secondary: str = "q.distribution_secondary"
    queue_distribution: str = "q.distribution"
    queue_dlq: str = "q.dlq"

    # YouTube OAuth / API
    youtube_client_id: str | None = None
    youtube_client_secret: str | None = None
    youtube_redirect_uri: str | None = None
    youtube_oauth_scope: str = "https://www.googleapis.com/auth/youtube.upload"
    youtube_token_url: str = "https://oauth2.googleapis.com/token"
    youtube_oauth_auth_url: str = "https://accounts.google.com/o/oauth2/v2/auth"
    youtube_api_upload_url: str = "https://www.googleapis.com/upload/youtube/v3/videos"
    youtube_strict_mode: bool = False
    youtube_daily_quota_limit: int = 100
    youtube_status_poll_url: str = "https://www.googleapis.com/youtube/v3/videos"
    youtube_webhook_secret: str | None = None

    # Model gateway
    model_provider: str = "none"  # none | openai_compatible | ollama | gemini
    model_api_base: str | None = None
    model_api_key: str | None = None
    model_name_default: str = "gpt-4o-mini"
    model_name_impact: str = "gpt-4o-mini"
    model_name_moderation: str = "gpt-4o-mini"
    model_name_classification: str = "gpt-4o-mini"
    model_name_compliance: str = "gpt-4o-mini"
    model_name_content: str = "gpt-4o-mini"
    model_name_localization: str = "gpt-4o-mini"
    model_name_reporter: str = "gpt-4o-mini"
    model_timeout_seconds: float = 30.0
    model_temperature: float = 0.2
    impact_confidence_min: float = 0.60
    model_retry_max_attempts: int = 4
    model_retry_backoff_initial_seconds: float = 1.0
    model_retry_backoff_multiplier: float = 2.0
    model_retry_backoff_max_seconds: float = 20.0

    # Gemini-specific config (Google Generative Language API)
    google_api_key: str | None = None
    gemini_api_key: str | None = None
    gemini_api_base: str = "https://generativelanguage.googleapis.com/v1beta"
    google_genai_use_vertexai: bool = False
    google_cloud_project: str | None = None
    google_cloud_location: str | None = None

    # Token encryption (Fernet key, base64 url-safe)
    token_encryption_key: str | None = None

    # Secondary connector
    secondary_channel_webhook_url: str | None = None
    secondary_channel_api_key: str | None = None
    secondary_channel_timeout_seconds: float = 20.0
    secondary_channel_retry_max_attempts: int = 3
    secondary_channel_strict_mode: bool = False

    # Upload security
    upload_max_file_size_bytes: int = 524288000
    upload_allowed_mime_types: str = "video/mp4,video/quicktime,video/x-msvideo,video/x-matroska"
    malware_scan_url: str | None = None
    malware_scan_api_key: str | None = None
    malware_scan_timeout_seconds: float = 15.0

    # Auth / RBAC
    auth_jwt_secret: str = "change-me"
    auth_jwt_algorithm: str = "HS256"
    auth_access_token_exp_minutes: int = 120
    auth_default_admin_username: str = "admin"
    auth_default_admin_password: str = "admin123"
    auth_default_moderator_username: str = "moderator"
    auth_default_moderator_password: str = "moderator123"
    auth_default_uploader_username: str = "uploader"
    auth_default_uploader_password: str = "uploader123"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @field_validator("upload_max_file_size_bytes")
    @classmethod
    def validate_upload_size(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("upload_max_file_size_bytes must be > 0")
        return v


settings = Settings()
